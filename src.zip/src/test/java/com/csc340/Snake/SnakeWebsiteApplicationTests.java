package com.csc340.Snake;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnakeWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
