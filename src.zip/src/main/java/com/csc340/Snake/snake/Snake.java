package com.csc340.Snake.snake;
import jakarta.persistence.*;


@Entity
@Table(name = "com/csc340/Snake/snake")
public class Snake {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int snakeId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String description;

    private double lengthM;

    public Snake(int snakeId, String name, String description, double lengthM) {
        this.snakeId = snakeId;
        this.name = name;
        this.description = description;
        this.lengthM = lengthM;
    }


    public Snake(String name, String description, double lengthM) {
        this.name = name;
        this.description = description;
        this.lengthM = lengthM;
    }

    public Snake(){




    }

    public int getSnakeId(){

        return snakeId;
    }

    public void setSnakeId(int snakeId) {
        this.snakeId = snakeId;
    }


    public String getName() {
        return name;
    }


    public void setName(String name){

        this.name = this.name;
    }

    public String getDescription() {
        return description;
    }


    public void setDescription(String description){

        this.description = this.description;

    }

    public double getLengthM() {
        return lengthM;
    }

    public void setLengthM(double lengthM) {
        this.lengthM = lengthM;
    }
}
