package com.csc340.Snake.snake;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SnakeRepository extends JpaRepository<Snake, Integer> {


    @Query(value = "select * from snakes s where s.length >= ?1", nativeQuery = true)
    List<Snake> getSnakesByLength(double lengthM);

    @Query(value = "select * from snakes s where s.name like %?1% ", nativeQuery = true)
    List<Snake> getSnakesByName(String name);
}







